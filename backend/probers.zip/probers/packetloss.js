const ping = require('ping');

exports.measure = async () => {
  const target = '8.8.8.8';
  try {
    const isWindows = process.platform === 'win32';
    const pingArgs = isWindows ? ['-n', '10'] : ['-c', '10'];
    
    const res = await ping.promise.probe(target, {
      timeout: 10,
      extra: pingArgs
    });
    
    const lossPct = parseInt(res.packetLoss) || 0;
    
    return {
      module: 'packetloss',
      status: 'success',
      data: {
        sent: 10,
        received: 10 - Math.round(lossPct * 10 / 100),
        loss_percentage: lossPct
      }
    };
  } catch (err) {
    return {
      module: 'packetloss',
      status: 'error',
      data: { loss_percentage: 100, sent: 10, received: 0 }
    };
  }
};
