const axios = require('axios');

exports.measure = async () => {
  const endpoints = {
    google: 'https://www.google.com',
    cloudflare: 'https://www.cloudflare.com',
    youtube: 'https://www.youtube.com',
    jio_cdn: 'https://www.jio.com'
  };

  const results = {};

  for (const [name, url] of Object.entries(endpoints)) {
    const start = Date.now();
    try {
      await axios.get(url, { timeout: 5000 });
      results[name] = Date.now() - start;
    } catch (err) {
      results[name] = -1;
    }
  }

  return {
    module: 'http',
    status: 'success',
    data: results
  };
};
