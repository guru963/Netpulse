const dns = require('dns').promises;

exports.measure = async () => {
  const domain = 'google.com';
  const resolvers = [
    { name: 'isp', ip: null }, // default
    { name: 'cloudflare_1_1_1_1', ip: '1.1.1.1' },
    { name: 'google_8_8_8_8', ip: '8.8.8.8' }
  ];

  const results = {};

  for (const resolver of resolvers) {
    let resolverInstance = dns;
    if (resolver.ip) {
      const { Resolver } = require('dns').promises;
      resolverInstance = new Resolver();
      resolverInstance.setServers([resolver.ip]);
    }
    
    const start = Date.now();
    try {
      await resolverInstance.resolve(domain);
      results[resolver.name] = Date.now() - start;
    } catch (err) {
      results[resolver.name] = -1; // -1 for error
    }
  }

  return {
    module: 'dns',
    status: 'success',
    data: results
  };
};
